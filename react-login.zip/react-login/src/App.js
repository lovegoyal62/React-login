import React, { useState, useEffect } from "react";
import LoginForm from "./compnents/LoginForm";

function App() {
  const adminUSer = {
    email: "task@gmail.com",
    password: "12345678"
  }

  const [user, setUser] = useState({ name: "", email: "" });
  const [error, setError] = useState("");

  useEffect(() => {
    localStorage.setItem('email', JSON.stringify(user.email));
    localStorage.setItem('password', JSON.stringify(user.password));
  }, [user.email][user.password]);

  const Login = details => {
    console.log(details);
    if (details.email == adminUSer.email && details.password == adminUSer.password) {
      console.log("logged in");
      setUser({
        name: details.name,
        email: details.email,
        password: details.password,
      })
    } else {
      console.log("Details doesn't match!");
      setError("Details doesn't Match..!");
    }
  }

  const Logout = () => {
    console.log("logout");
    setUser({ name: "", email: "" });
  }

  return (
    <div className="App">
      {(user.email != "") ? (
        <div className="welcome">
          <h2>welcome<span>{user.name}</span></h2>
          <button onClick={Logout}>logout</button>
        </div>
      ) : (
        <LoginForm Login={Login} error={error} />
      )}
    </div>
  );
}

export default App;
